﻿using UnityEngine;
using System.Collections;

public class api : MonoBehaviour {

	gerak KomponenGerak;
	
	// Use this for initialization
	void Start () {
		KomponenGerak = GameObject.Find("mobil").GetComponent<gerak>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	
	void OnTriggerEnter2D (Collider2D other){
		if (other.transform.tag == "Player") {
			KomponenGerak.nyawa--;
			KomponenGerak.koin++;
			Destroy(gameObject);
		}
	}
}
